# Gatekeeper AI 🛡️

> Autonomous code quality enforcement with AI-powered repair

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Python 3.11+](https://img.shields.io/badge/python-3.11+-blue.svg)](https://www.python.org/downloads/)

Created by **Francois Roux** | [frankroux@gmail.com](mailto:frankroux@gmail.com) | [@frarouAI](https://github.com/frarouAI)

## Features

- ✅ **Autonomous Code Judging** - AI-powered code quality analysis
- ✅ **Iterative Repair** - Automatically fix code quality issues
- ✅ **Schema Versioning** - Future-proof artifact storage
- ✅ **CI/CD Integration** - Block bad code before it merges
- ✅ **Audit Trails** - Immutable repair evidence
- ✅ **Configurable** - YAML-based configuration
- ✅ **Enterprise-Ready** - SOC2/ISO compliant artifacts

## Quick Start

### Installation
```bash
pip install gatekeeper-ai
```

Or install from GitHub:
```bash
pip install git+https://github.com/frarouAI/gatekeeper-ai.git
```

### Usage

**1. Initialize configuration:**
```bash
gatekeeper init
```

**2. Judge a file:**
```bash
gatekeeper judge myfile.py --profile strict
```

**3. Repair with dry-run:**
```bash
gatekeeper repair myfile.py --dry-run
```

**4. Live repair:**
```bash
gatekeeper repair myfile.py --live
```

### Configuration

Create `.gatekeeper.yml` in your project root:
```yaml
version: 1
profile: strict

ci:
  enabled: true
  fail_on_non_compliant: true
  fail_on_confidence_below: 0.85

repair:
  enabled: true
  mode: dry-run
  max_iterations: 3
  confidence_threshold: 0.9

artifacts:
  retention_days: 180
  store_diff: true
  validate_schema: true

paths:
  include:
    - "**/*.py"
  exclude:
    - "tests/**"
    - ".venv/**"
```

### GitHub Actions

Add `.github/workflows/gatekeeper.yml`:
```yaml
name: Gatekeeper AI

on: [pull_request, push]

jobs:
  quality-gate:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: "3.11"
      - run: pip install gatekeeper-ai
      - run: gatekeeper-ci
        env:
          ANTHROPIC_API_KEY: ${{ secrets.ANTHROPIC_API_KEY }}
```

## Architecture
```
┌─────────────────┐
│   Your Code     │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│  Judge Engine   │  ← Finds quality issues
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│  Repair Agent   │  ← Claude proposes fixes
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│  Loop Control   │  ← Iterative improvement
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│   Artifacts     │  ← Immutable audit trail
└─────────────────┘
```

## License

MIT License - Copyright (c) 2026 Francois Roux

See [LICENSE](LICENSE) for details.

## Contact

- **Author:** Francois Roux
- **Email:** frankroux@gmail.com
- **GitHub:** [@frarouAI](https://github.com/frarouAI)
- **Project:** [github.com/frarouAI/gatekeeper-ai](https://github.com/frarouAI/gatekeeper-ai)
